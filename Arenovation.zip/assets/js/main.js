//accardion
function accardion(element) {
    element.children[0].children[1].classList.toggle('rotate');
    element.children[1].classList.toggle('product-active');
}


//slider
const slides = document.querySelectorAll('.slide');
let activeSlide = 0;
let width = 0;
let flag = true

function slider(factor) {
    flag = false;
    width = 0;
    document.querySelector('.state-slider').style.width = width + '%';
    slides[activeSlide].classList.remove('active');

    activeSlide += factor;

    if (activeSlide < 0) {
        activeSlide = slides.length - 1;
    } else if (activeSlide > slides.length - 1) {
        activeSlide = 0;
    }

    slides[activeSlide].classList.add('active');

    setTimeout(() => {
        flag = true;
    }, 2000);
    clearTimeout();
}

setInterval(() => {
    if (flag) {
        width += 0.04;
        document.querySelector('.state-slider').style.width = width + '%';
        if (width >= 100) {
            slider(1);
            width = 0;
        }
    }
}, 1);


//tabs
const tabBtns = document.querySelectorAll('.tab-btn');
const tabs = document.querySelectorAll('.tab');

function tab(index) {
    tabs.forEach(element => {
        element.classList.remove('active');
    });
    tabBtns.forEach(element => {
        element.classList.remove('active');
    });

    tabBtns[index].classList.add('active');

    tabs[index].classList.add('active');
}


//burger
function burgerMenu() {
    const burgerButton = document.querySelectorAll('.burger-button');
    burgerButton[0].classList.toggle('burger-close')
    burgerButton[1].classList.toggle('burger-close')

    document.querySelector('.burger').classList.toggle('burger-none');
}