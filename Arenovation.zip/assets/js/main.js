//accardion
function accardion(element) {
    element.children[0].children[1].classList.toggle('rotate');
    element.children[1].classList.toggle('product-active');
}

