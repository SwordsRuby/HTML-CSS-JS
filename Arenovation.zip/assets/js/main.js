//accardion
function accardion(element) {
    element.children[0].children[1].classList.toggle('rotate');
    element.children[1].classList.toggle('product-active');
}


//slider
const slides = document.querySelectorAll('.slide');
let activeSlide = 0;
let width = 0;

function slider(factor) {
    slides[activeSlide].classList.remove('active');

    activeSlide += factor;

    if (activeSlide < 0) {
        activeSlide = slides.length - 1;
    } else if (activeSlide > slides.length - 1) {
        activeSlide = 0;
    }

    slides[activeSlide].classList.add('active');
    width = 0;
    document.querySelector('.state-slider').style.width = width + '%';
}

setInterval(() => {
    width += 10;
    document.querySelector('.state-slider').style.width = width + '%';
    if (width >= 100) {
        slider(1);
        width = 0;
    }
}, 1000);


//tabs
const tabBtns = document.querySelectorAll('.tab-btn');
const tabs = document.querySelectorAll('.tab');

function tab(index) {
    tabs.forEach(element => {
        element.classList.remove('active');
    });
    tabBtns.forEach(element => {
        element.classList.remove('active');
    });

    tabBtns[index].classList.add('active');

    tabs[index].classList.add('active');
}